<link rel = "stylesheet"  type = "text/css"  href = "css/main.css" />
<div class="wrapper">
  <div class="box header">@include('layouts/header')</div>
  <div class="box sidebar">@include('layouts/menu')</div>
  <div class="box content">@yield('content')</div>
  <div class="box footer">Footer</div>
</div>