<h1>Main Menu</h1>
<a href='user'>List users</a>