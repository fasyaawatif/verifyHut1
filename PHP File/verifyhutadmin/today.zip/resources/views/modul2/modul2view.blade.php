<h1>Modul Kedua</h1>
<h2>{{ $str }}<h2>
<h3>{{ $msg }}<h3>


