@extends('layouts/main');
@section('content')
<h1>ALL USERS</h1>
<a href='logout'>Logout</a>
<h2>Welcome {{ Session::get('pengguna') }} - {{ Session::get('nama') }}</h2>
<a href='user_insertnewuser'>ADD NEW USER</a>

<table border=1>
@foreach ($listofuser as $u)
	<tr>
		<td> {{$u->nama}} </td>
		<td> {{$u->nomatrik}} </td>
		<td> {{$u->email}} </td>		
	</tr>
@endforeach
</table>
@endsection