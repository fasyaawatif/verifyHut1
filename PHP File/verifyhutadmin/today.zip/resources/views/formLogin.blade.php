<form method='POST' action='login'>
Username : <input type='text' name='u'><br>
Password : <input type='password' name='p'><br>
<input type='submit' name='btn' value='Login'>
{!! Form::token() !!}
</form>