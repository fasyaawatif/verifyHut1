<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class MyController extends Controller
{
    public function logout(){
		session()->flush();
		return redirect('dologin');
	}
	
	public function login(Request $r){
		$username=  $r->u;
		$password = $r->p;
		$password = sha1($password);
		$result = \App\user::where("nomatrik","=",$username)
				->where("password","=",$password)
				->get();
		if ($result->count()>0){
			echo "Berjaya";
			session(['pengguna' => $username,
					'email' => $result[0]->email,
					'nama'=>$result[0]->nama,
					'level'=>$result[0]->level
					]);
			return redirect('user');
		}else{
			echo "Not a valid login";			
		}
	}
	
	
	public function viewuser(){
		if (session('pengguna')){
			if (session('level')==1){
				$listofuser = \App\user::all();
			}else{
				$listofuser = \App\user::where('nomatrik','=',session('pengguna'))
							->get();
			}			
			return view('viewUser',compact('listofuser'));		
		}else{
			echo "Please login first!";
		}
	}
	
	public function insertnewuser(Request $r){
		echo "Trying to insert new user...<br>";	
		
		$newuser = new \App\user;
		$newuser->nama = $r->nama;
		$newuser->nomatrik = $r->nomatrik;
		$newuser->email = $r->email;
		$newuser->save();
		
		return redirect('user');
	}
			
}

/*
public function index()
    {
        return "Index of MyController";
    }
	
	public function CCC()
    {
        return "This is CCC function";
    }
*/	


//LIKE SQL
		//::where('email','LIKE','%gmail.com')
		//->get();
		
		//AND SQL
		//::where('id',"=",'1','and')
		//->where('nama',"=",'Suhailan')
		//->get();